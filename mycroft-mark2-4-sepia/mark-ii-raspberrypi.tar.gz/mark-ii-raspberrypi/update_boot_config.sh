#!/bin/bash

# Detect the config file path
if [ -f /boot/firmware/config.txt ]; then
    CONFIG="/boot/firmware/config.txt"
elif [ -f /boot/config.txt ]; then
    CONFIG="/boot/config.txt"
else
    echo "Error: No config.txt found!"
    exit 1
fi

echo "Processing Config: $CONFIG"

# Function to safely comment out and append the new value
update_config_parameter() {
    local search_pattern="$1"
    local new_line="$2"

    # Check if the exact new line is already active to avoid duplicates
    if grep -q "^${new_line}" "$CONFIG"; then
        echo "[SKIP] '${new_line}' is already active."
        return
    fi

    # Check if any version of the parameter is currently active (uncommented)
    if grep -q "^${search_pattern}" "$CONFIG"; then
        # Comment out the active line and append the new version below it
        sudo sed -i "s|^${search_pattern}.*|# & \n${new_line}|" "$CONFIG"
        echo "[CMT+] Active parameter commented out and replaced with: ${new_line}"

    # Check if a commented version already exists
    elif grep -q "^#.*${search_pattern}" "$CONFIG"; then
        # Append the new line after the last commented occurrence
        sudo sed -i "/^#.*${search_pattern}/a ${new_line}" "$CONFIG"
        echo "[ADD+] Commented parameter found. Added new value below: ${new_line}"

    # If it doesn't exist at all
    else
        echo "${new_line}" | sudo tee -a "$CONFIG" > /dev/null
        echo "[APPEND] New parameter added to the end: ${new_line}"
    fi
}

# 1. Handle dtparam=audio
update_config_parameter "dtparam=audio=" "dtparam=audio=off"

# 2. Handle vc4-kms-v3d / vc4-fkms-v3d
# The regex looks for kms or fkms
update_config_parameter "dtoverlay=vc4-.*kms-v3d" "dtoverlay=vc4-kms-v3d,noaudio"

echo "Done. Please verify the file and reboot."
