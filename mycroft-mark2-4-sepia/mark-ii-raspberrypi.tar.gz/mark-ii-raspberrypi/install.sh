#!/usr/bin/bash
set -ex

# Directory of *this* script
this_dir="$( cd "$( dirname "$0" )" && pwd )"

# -----------------------------------------------------------------------------

echo 'Installing required packages'
sudo apt-get update
sudo apt-get install --yes python3 python3-venv python3-dev rsync i2c-tools

echo 'Copying system files'
sudo rsync -av "${this_dir}/files/" /

# Build kernel module for XMOS microphone chip
echo 'Building kernel module for microphone'
cd /opt/mycroft/xmos-microphone/vocalfusion/vocalfusion-rpi-setup-5.2.0
./setup.sh xvf3510-int

# Create virtual environment for XMOS firmware programming
echo 'Setting up microphone service'
cd /opt/mycroft/xmos-microphone
sudo ./install.sh
sudo systemctl enable mycroft-xmos.service

echo 'Setting up DBus service'
cd /opt/mycroft/dbus-hal
sudo ./install.sh
sudo systemctl enable mycroft-hal.service

# Small script to turn off LEDS on boot, etc.
sudo systemctl enable mycroft-boot.service

# -----------------------------------------------------------------------------

# Check for vfctrl_i2c (required for XMOS vocalfusion audio chip)
if ! command -v vfctrl_i2c &> /dev/null; then
    echo ""
    echo "WARNING: vfctrl_i2c not found after XMOS setup!"
    prebuilt_vfctrl="$this_dir/pre-built/usr/bin/vfctrl_i2c"
    if [ -f "$prebuilt_vfctrl" ]; then
        read -p "vfctrl_i2c missing, copy pre-built fallback binary? [y/N] " confirm
        if [ "$confirm" = "y" ] || [ "$confirm" = "Y" ]; then
            sudo cp "$prebuilt_vfctrl" /usr/local/bin/
            sudo chmod +x /usr/local/bin/vfctrl_i2c
            echo "Done."
        else
            echo "Skipped. Note: Mark II audio chip control may not work correctly."
        fi
    else
        echo "ERROR: pre-built fallback also missing! Please check XMOS installation."
    fi
fi

# -----------------------------------------------------------------------------

echo 'Installation complete.'
echo 'Please reboot your Raspberry Pi after the boot config update.'

# Modify /boot/config.txt
sudo ./update_boot_config.sh
